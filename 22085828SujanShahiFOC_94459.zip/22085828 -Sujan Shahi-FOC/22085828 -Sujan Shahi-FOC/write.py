def updateRented_land(filename, rent):
    # Open file for writing
    file = open(filename,"w")
    # Iterate over rented lands
    for key, details in rent.items():
        # Extract details of each land
        kitta_number = details["kitta_number"]
        city_district = details["city_district"]
        direction = details["direction"]
        area = details["area"]
        price = details["price"]
        availability = details["availability"]
        # Construct a line with land details
        line = key + ", " + kitta_number + ", " +city_district + ", " +direction+ ", "+ str(area) + ", " + str(price) + ", " + availability
        file.write(line)
        file.write("\n")  
