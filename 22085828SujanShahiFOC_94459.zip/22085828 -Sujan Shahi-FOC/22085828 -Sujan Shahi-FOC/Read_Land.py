def read_LandRentals(file_name):
    land_rentals = {}  # dictionary
    with open(file_name, "r") as file: # Open the file in read mode
        for line in file:
            data = line.split(", ")
            index = data[0]
            kitta_number = data[1]
            city_district = data[2]
            direction = data[3]
            area = int(data[4])
            price = int(data[5])
            availability = data[6]
            
            if availability.endswith('\n'): # Check if availability ends with newline character
                availability = availability[:-1] # Remove the newline character

            
            land_rentals[index] = {
                "kitta_number": kitta_number,
                "city_district": city_district,
                "direction": direction,
                "area": area,
                "price": price,
                "availability": availability
            }
          
    return land_rentals # Return the dictionary containing land rental data


