import Read_Land as rd
import random

def land_properties(rent):
     # Displaying header for land properties
    print("\t")
    print("**************************************************************************************************************************")
    print("| {:<14} | {:<31} | {:<10} | {:<9} | {:<6} | {:<15} | {:<15} |".format("index", "kitta_number", "city", "direction", "anna", "Rupees", "availability"))
    print("**************************************************************************************************************************")
    index=1
    # Printing details of each land
    for key,value in rent.items():
        kitta_number = value["kitta_number"]
        city_district = value["city_district"]
        direction = value["direction"]
        area = value["area"]
        price = value["price"]
        avaibility = value["availability"]
        print("| {:<14} | {:<31} | {:<10} | {:<9} | {:<6} | {:<15} | {:<15} |".format(index, kitta_number, city_district, direction, area, price, avaibility)) 
        index+=1
    print("**************************************************************************************************************************")


def rent_land(rent,customer_name):
    total_price=0
    rented_land=[]
    index= "e"

     # Loop for renting lands
    while True:
        try:
            land_properties(rent)
             # Checking if all lands are rented
            if (rent["1"]["availability"].lower() == "not available" and rent["2"]["availability"].lower() == "not available" and rent["3"]["availability"].lower() == "not available"):
                print("All the lands are rented")
                break
            index = input("Enter the number of the index you want to rent or 'e' to exit: ")

            if index.lower() == "e" or index.lower == "exit":
                break
            if index not in rent:
                print("Invalid input!")
                continue

            if(rent[index]["availability"].lower() == "not available"):
                print("The land is not available to rent")
                continue
            time_in_month = int(input("Enter for how many months you want to rent the land: "))
            # Calculating total price for renting
            total_price = total_price + int((rent[index]["price"])) * time_in_month

            if(rent[index]["availability"].lower() == "available"):

                rented_land.append({
                    "Customer name": customer_name,
                    "kitta_number": rent[index]["kitta_number"],
                    "city_district": rent[index]["city_district"],
                    "direction": rent[index]["direction"],
                    "area": rent[index]["area"],
                    "price": rent[index]["price"],
                    "availability": rent[index]["availability"]
                })
             # Updating availability of rented land
            rent[index]["availability"] = "Not Available"

            add_land = input("Do you want to add more lands to rent? (y/n): ")
            if add_land.lower() == "n":
                break
        except Exception as e:
            print("An error occurred:", e)
            continue

    if (index.lower() != "e") and (index.lower() != "exit"):
      # Generating bill for rented lands
            bill= customer_name  + "Rented land"
            file= open(bill,"a") 
            file.write("\n\n")
            file.write("******************************************************************************************\n")
            file.write("                                   TechnoPropertyNepal\n")
            file.write("******************************************************************************************\n")
            file.write("                   Bhaisepati, Lalitpur | Contact number: 9813902298\n")
            file.write("******************************************************************************************\n")
            file.write("                                         Invoice\n")
            file.write("******************************************************************************************\n\n")
            file.write("   Customer Name: {}\n\n".format(customer_name))
            file.write("******************************************************************************************\n")
            file.write("{:<15} | {:<20} | {:<15} | {:<10} | {:<15}\n".format("Kitta Number", "City/District", "Direction", "Area", "Price (NPR)"))
            file.write("******************************************************************************************\n")
            for Land in rented_land:
                file.write("| {:<13} | {:<20} | {:<15} | {:<10} | {:<15}  |\n".format(Land["kitta_number"], Land["city_district"], Land["direction"], Land["area"], str(Land["price"])))
            file.write("------------------------------------------------------------------------------------------\n")
            file.write("   Total: {} NPR\n".format(total_price))
            file.write("------------------------------------------------------------------------------------------\n")
            # Printing bill details
            print("\n\n******************************************************************************************\n")
            print("                                   TechnoPropertyNepal\n")
            print("******************************************************************************************\n")
            print("                   Bhaisepati, Lalitpur | Contact number: 9813902298\n")
            print("******************************************************************************************\n")
            print("                                         Invoice\n")
            print("******************************************************************************************\n\n")
            print("   Customer Name: {}\n".format(customer_name))
            print("******************************************************************************************\n")
            print("{:<15} | {:<20} | {:<15} | {:<10} | {:<15}\n".format("Kitta Number", "City/District", "Direction", "Area", "Price (NPR)"))
            print("******************************************************************************************\n")
            for Land in rented_land:
                print("| {:<13} | {:<20} | {:<15} | {:<10} | {:<15}  |".format(Land["kitta_number"], Land["city_district"], Land["direction"], Land["area"], str(Land["price"])))
            print("\n------------------------------------------------------------------------------------------\n")
            print("   Total: {} NPR\n".format(total_price))
            print("\n------------------------------------------------------------------------------------------\n")


def return_land(rent,customer_name):
    total_price=0
    rented_land=[]

    
    time_in_month = 0
    time_to_return = 0
    # Loop for returning lands
    while True:

        land_properties(rent)
        index = input("Enter the number of the index you want to return or 'e' to exit: ")
         # Checking if all lands are returned
        if(rent["1"]["availability"].lower() == "available" and rent["2"]["availability"].lower() == "available" and rent["3"]["availability"].lower() == "available"):
            print("All the lands are returned")
            break
        time_in_month = int(input("Enter for how many months you have rented the land: "))
        time_to_return = int(input("Enter when you should have returned the land: "))
        
        if index.lower() == "e" or index.lower == "exit":
            break
        if index not in rent:
            print("Invalid input!")
            continue
        
        
        if(rent[index]["availability"].lower() == "available"):
            print("The land is not in our list!")
            continue

        if(rent[index]["availability"].lower() == "not available"):
            rented_land.append({
                "Customer name":customer_name,
                "kitta_number" :rent[index]["kitta_number"],
                "city_district": rent[index]["city_district"],
                "direction": rent[index]["direction"],
                "area": rent[index]["area"],
                "price": rent[index]["price"],
                "availability": rent[index]["availability"]
            })

        rent[index]["availability"] = "Available"
        
       

        add_land= input("Do you want to return more ?(y/n): ")
        if add_land.lower()=="n":
            break
    # Generating bill for returned lands
    random_number = random.randint(1, 100)
    bill= customer_name  + " Returned land"

    if (index.lower() != "e") and (index.lower() != "exit"):
        if(time_in_month and time_to_return != 0):
            if(time_to_return >= time_in_month):
                total_price =  total_price + int((rent[index]["price"])) * time_in_month
                file= open(bill,"a") 
                file.write("\n\n")
                file.write("******************************************************************************************\n")
                file.write("                                   TechnoPropertyNepal\n")
                file.write("******************************************************************************************\n")
                file.write("                   Bhaisepati, Lalitpur | Contact number: 9813902298\n")
                file.write("******************************************************************************************\n")
                file.write("                                         Invoice\n")
                file.write("******************************************************************************************\n\n")
                file.write("   Customer Name: {}\n\n".format(customer_name))
                file.write("******************************************************************************************\n")
                file.write("{:<15} | {:<20} | {:<15} | {:<10} | {:<15}\n".format("Kitta Number", "City/District", "Direction", "Area", "Price (NPR)"))
                file.write("******************************************************************************************\n")
                for Land in rented_land:
                    file.write("| {:<13} | {:<20} | {:<15} | {:<10} | {:<15}  |\n".format(Land["kitta_number"], Land["city_district"], Land["direction"], Land["area"], str(Land["price"])))
                file.write("------------------------------------------------------------------------------------------\n")
                file.write("   Total: {} NPR\n".format(total_price))
                file.write("------------------------------------------------------------------------------------------\n")

                print("\n\n******************************************************************************************\n")
                print("                                   TechnoPropertyNepal\n")
                print("******************************************************************************************\n")
                print("                   Bhaisepati, Lalitpur | Contact number: 9813902298\n")
                print("******************************************************************************************\n")
                print("                                         Invoice\n")
                print("******************************************************************************************\n\n")
                print("   Customer Name: {}\n".format(customer_name))
                print("******************************************************************************************\n")
                print("{:<15} | {:<20} | {:<15} | {:<10} | {:<15}\n".format("Kitta Number", "City/District", "Direction", "Area", "Price (NPR)"))
                print("******************************************************************************************\n")
                for Land in rented_land:
                    print("| {:<13} | {:<20} | {:<15} | {:<10} | {:<15}  |".format(Land["kitta_number"], Land["city_district"], Land["direction"], Land["area"], str(Land["price"])))
                print("\n------------------------------------------------------------------------------------------\n")
                print("   Total: {} NPR\n".format(total_price))
                print("\n------------------------------------------------------------------------------------------\n")
            else :
                total_price =  (total_price + int((rent[index]["price"])) * time_in_month) + 0.2* int((rent[index]["price"]))
                file= open(bill,"a") 
                file.write("\n\n")
                file.write("******************************************************************************************\n")
                file.write("                                   TechnoPropertyNepal\n")
                file.write("******************************************************************************************\n")
                file.write("                   Bhaisepati, Lalitpur | Contact number: 9813902298\n")
                file.write("******************************************************************************************\n")
                file.write("                                         Invoice\n")
                file.write("******************************************************************************************\n\n")
                file.write("   Customer Name: {}\n\n".format(customer_name))
                file.write("******************************************************************************************\n")
                file.write("{:<15} | {:<20} | {:<15} | {:<10} | {:<15}\n".format("Kitta Number", "City/District", "Direction", "Area", "Price (NPR)"))
                file.write("******************************************************************************************\n")
                for Land in rented_land:
                    file.write("| {:<13} | {:<20} | {:<15} | {:<10} | {:<15}  |\n".format(Land["kitta_number"], Land["city_district"], Land["direction"], Land["area"], str(Land["price"])))
                file.write("------------------------------------------------------------------------------------------\n")
                file.write("   Total: {} NPR\n".format(total_price))
                file.write("since you have delayed to return the land in time, you need to pay 20 % " +"fine of original price\n")
                file.write("------------------------------------------------------------------------------------------\n")

                print("\n\n******************************************************************************************\n")
                print("                                   TechnoPropertyNepal\n")
                print("******************************************************************************************\n")
                print("                   Bhaisepati, Lalitpur | Contact number: 9813902298\n")
                print("******************************************************************************************\n")
                print("                                         Invoice\n")
                print("******************************************************************************************\n\n")
                print("   Customer Name: {}\n".format(customer_name))
                print("******************************************************************************************\n")
                print("{:<15} | {:<20} | {:<15} | {:<10} | {:<15}\n".format("Kitta Number", "City/District", "Direction", "Area", "Price (NPR)"))
                print("******************************************************************************************\n")
                for Land in rented_land:
                    print("| {:<13} | {:<20} | {:<15} | {:<10} | {:<15}  |".format(Land["kitta_number"], Land["city_district"], Land["direction"], Land["area"], str(Land["price"])))
                print("\n------------------------------------------------------------------------------------------\n")
                print("   Total: {} NPR\n".format(total_price))
                print("since you have delayed to return the land in time, you need to pay 20 % " +"fine of original price\n")
                print("\n------------------------------------------------------------------------------------------\n")