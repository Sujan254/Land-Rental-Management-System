import Read_Land as rd  
import operation as op  
import write as wr      

def main():
    try:
        # Reading land rental data
        rent = rd.read_LandRentals("rental_land.txt") 
        
        while True:
            # Displaying menu options
            print('''
                ╔════════════════════════════════════════════════════════════════════╗
                ║                                                                    ║
                ║                  WELCOME TO TechnoPropertyNepal                    ║
                ║                                                                    ║
                ║********************************************************************║
                ║ PLEASE SELECT A CATEGORY AS (1,2,3,4), ACCORDING TO YOUR OPTION:   ║
                ║                                                                    ║
                ║                        1 = SHOW LANDS                              ║
                ║                        2 = RENT LANDS                              ║
                ║                        3 = RETURN LANDS                            ║    
                ║                        4 = EXIT                                    ║                                                                    
                ║                                                                    ║
                ╚════════════════════════════════════════════════════════════════════╝        
                         ''')
            option = int(input("Enter your option: "))  # Taking user input for option
            
           
            if option == 1:   
                op.land_properties(rent)  # Showing available lands
            elif option == 2:
                try:
                    name = input("Enter your full name: ")
                    if name == "":
                        print("Name should not be empty!")
                        continue
                    if any(char.isdigit() for char in name):
                        raise ValueError
                except ValueError:
                    print("Name must not contain numbers")
                op.rent_land(rent,name)   # Renting land
                wr.updateRented_land("rental_land.txt",rent)  # Updating rented land data
                
            elif option == 3:
                try:
                    name = input("Enter your full name: ")
                    if name == "":
                        print("Name should not be empty!")
                        continue
                    if any(char.isdigit() for char in name):
                        raise ValueError
                except ValueError:
                    print("Name should not contain number!")
                op.return_land(rent,name)  # Returning rented land
                wr.updateRented_land("rental_land.txt",rent)  # Updating rented land data
        
            elif option == 4:
                print("Thank You For Visiting TechnoPropertyNepal, Do Visit Again.")
                break  
            
            else:
                print("Invalid option! Please choose a number between 1 and 4.")
                continue  
                
    except ValueError:
        print("Invalid input! Please enter a number between 1 and 4.")
        main()  

main()  # Calling main function to start the program
